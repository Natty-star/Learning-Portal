<?php
//Database Constants local


define("DBHOST", "localhost");
define("DBNAME", "arif_payment_api");
define("DBUSER", "arif_arifuser");
define("DBPASS", "taktechnologiesplc@12345");



//Database server
/*
define("DBHOST", "127.0.0.1");
define("DBNAME", "arif_payment_api");
define("DBUSER", "root");
define("DBPASS", "");
*/



//Path Constants
//define("MAINURL", "http://localhost/arif2/");
define("MAINURL", "http://arif.et/");
define("HOME", MAINURL);
define("LESSSONURL", MAINURL."lessons.php");
define("EXAM", MAINURL."exam.php");
define("SUBSCRIBE", MAINURL."subscribe.php");
define("CONFIRM", MAINURL."confirm.php");
define("TERMS", MAINURL."terms_and_conditions.php");
define("JOKES", MAINURL."subscribe_joke.php");
define("SUBJOKES", MAINURL."confirm_joke.php");
define("UNSUBSCRIBE", MAINURL."unsubscribe.php");
define("PRIZE", MAINURL."prizeexam.php");


